import 'package:flutter/material.dart';

import '../../../constants.dart';

// We need satefull widget for our categories

class categories extends StatefulWidget {
  @override
  _categoriesState createState() => _categoriesState();
}

class _categoriesState extends State<categories> {
  List<String> categories = ["Hand bag", "Jewellery", "Footwear", "Dresses"];
  // By defalt our first item will be selected
  int selectedIndex = 0;

  get kTextLigtColor => null;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: kDefaultPaddin),
      child: SizedBox(
        height: 25,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: categories.length,
          itemBuilder: (context, index) => buildCategory(index)
            )
      ),
    );
  }

  Widget buildCategory(int index) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: kDefaultPaddin),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
                categories[index],
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: selectedIndex == index ? kTextColor : kTextLigtColor,
                ),
                ),
                Container(
                  margin: EdgeInsets.only(top: kDefaultPaddin / 4), // top padding 5
                  height: 2,
                  width: 30,
                  color: selectedIndex == index ? Colors.black : Colors.transparent,
                )
          ],
        ),
      ),
    );
  }
}
